## Gemini Added Memories
- The user needs to grant 'Pub/Sub Publisher' and 'Pub/Sub Subscriber' roles to the service account '131065304705-compute@developer.gserviceaccount.com' in the Google Cloud Console for project 'anonymous-hubs-477707'.
- The user needs to grant 'Pub/Sub Publisher' and 'Pub/Sub Subscriber' roles to the service account '131065304705-compute@developer.gserviceaccount.com' in the Google Cloud Console for project 'anonymous-hubs-477707'.
- The user needs to grant 'Pub/Sub Publisher' and 'Pub/Sub Subscriber' roles to the service account '131065304705-compute@developer.gserviceaccount.com' in the Google Cloud Console for project 'anonymous-hubs-477707'.
- The user will provide an updated version of the cocreator app. The current chat history should be saved for future usage.
- The system is primarily using `gemini-2.5-flash` for its operations, which is generally the most cost-effective Gemini model. The batch processing changes affect duration, not per-company API call cost. User should monitor Google Cloud billing for costs.
- The user wants to use Vertex AI for the project 'cocreator-d0nbh' instead of the Google Gemini API.
- Implemented real-time log streaming for Freqtrade bot. Backend endpoint `/ws/logs` streams `freqtrade_backend.log`. Frontend `BotControls` has a toggleable log viewer.
- Implemented visual updates for bot status: SignalList now displays whitelisted pairs with animations (blinking for scanning, glowing for signals). Backend endpoint `/api/v1/bot/whitelist` added to support this. App.tsx updated to fetch and manage whitelist state.
- The Hydra dashboard now features a fully integrated Freqtrade bot interface. It streams logs in real-time, visualizing bot activity. The Signal List visualizes the whitelist, indicating open trades with green (long) or red (short) glows, and scanning pairs with a yellow pulse. The Strategy was updated to spot-only (can_short=False). Connectivity to the backend (port 8001) is confirmed working.
- The system was switched to Futures trading mode. Manual execution was updated to use CCXT with manual Testnet URL configuration to bypass deprecation warnings. The user encountered an "Invalid Api-Key ID" error, indicating the API key in .env is not recognized by the Binance Futures Testnet endpoint. Troubleshooting focuses on verifying the key's origin and validity.
- The Hydra project has explicitly chosen to use the `binance-connector` Python SDK instead of `ccxt` for connecting to the Binance Futures Testnet due to connection reliability issues with `ccxt`. The implementation details and architectural choices are documented in `frontend/Dossie Tecnico.md`, which serves as a guide for institutional-grade trading features like Auction Market Theory and Order Flow. All future market data fetching (klines, trades, order book) should be implemented using `binance-connector` methods (`kline_candlestick_data`, `recent_trades_list`, `order_book`).
- Implemented TradingView widgets (TickerTape, AdvancedChart) and MarketSentimentHeader. Added chart mode toggle (Hydra/TV) in App.tsx. Fixed TS errors in SMCSeries.ts and others. Build passing.
- Implemented 'Execution Mode' toggle (Market/Chase) in ActionDeck.tsx. Frontend sends 'execution_mode' in payload. Verified FVG logic. Updated GEMINI.md. Build passing. Next: Backend Chase logic.
- Implemented 'WidgetToolbar' in the header for quick access to TradingView widgets (Technical Analysis, Market Overview, Symbol Info).
- Implemented 'DrawingManager' and 'DrawingOverlay' to add interactive custom drawing tools (Trendline, Rectangle) to the native lightweight-chart.
- The project is migrating from 'lightweight-charts' to 'klinecharts' to improve chart performance and gain native support for drawing tools and indicators.
- The project now supports four charting engines: Native (Lightweight Charts), Regular KlineCharts (v9.8.12), Pro KlineCharts, and TradingView Advanced Widget. KlineCharts v10.0.0-beta1 was avoided due to compatibility issues with the Pro version.
- Rewrote the Hydra backend from Python (FastAPI) to Rust (Tauri Core). 
- Ported Data Access (SQLite) to `db.rs`.
- Ported Binance Futures Execution to `binance_client.rs`.
- Implemented Real-Time Websocket Manager in `market_stream.rs`.
- Created `frontend/MIGRATION_GUIDE.md` for the React migration.
- Implemented "Chase" order logic in Rust (`frontend/src-tauri/src/chase.rs`) and exposed it via the `start_chase` Tauri command.
- Ported from `executor_module/spot_executor.py` and `executor_module/futures_executor.py`.
- Added `get_ticker_book`, `get_order`, and `cancel_order` to `BinanceClient`.
- Verified compilation with `cargo check`.
- Implemented "Bot Status" check in Rust (`frontend/src-tauri/src/process.rs`) and exposed it via the `get_bot_status` Tauri command.
- Replaced Python endpoint call in `useHydraData.ts`.
- Implemented `sysinfo` process check for "freqtrade".
- Added database path validation logging.
- Verified compilation with `cargo check`.
- Hydra Professional EA code compiled successfully with 0 errors in the Linux/Bottles environment.
- Hydra Strategy State: Active on XAUUSD M15 (Demo). Strategy: Mean Reversion (InpUseMeanRev=true). Risk: 1%. Current Status: Operational with open trades. Next Step: Analyze live performance and expand to other assets.
- Hydra Project Roadmap:
1. Short-term (Current Week): Accumulate "Track Record" on XAUUSD/GBPUSD using Quantamental Strategy (Bias Overlay) to validate profitability.
2. Mid-term (Next Week): Refactor code for MQL5 Market compliance (Fix memory leaks, add Error Handling, create GUI/Dashboard).
3. Goal: Launch "Hydra Professional" as a premium product with a "Quantamental" narrative.
- Talos V4.0 Live Performance (29/01): Successfully recovered Gold drawdown with a sniper reversal trade. Currently profitable in US500 and USOIL using Adaptive Trending (KAMA). Equity is above initial deposit. Strategy validated for Quantamental approach.
