//+------------------------------------------------------------------+
//|                                                     CEngine.mqh  |
//|                                  Copyright 2026, Hydra Project.  |
//+------------------------------------------------------------------+
#include <Trade\Trade.mqh>
#include <Trade\PositionInfo.mqh>
#include "..\Signals\ISignal.mqh"
#include "..\Signals\CSignalKAMA.mqh"
#include "..\Signals\CSignalMeanRev.mqh"
#include "..\Signals\CSignalBreakout.mqh"
#include "..\Risk\CRiskManager.mqh"
#include "..\Utils\CRegimeFilter.mqh"

enum ENUM_BIAS_MODE { BIAS_NONE, BIAS_LONG, BIAS_SHORT };

struct HydraSettings
{
   bool use_adaptive; bool use_kama; bool use_mean_rev; bool use_breakout;
   int kama_per; int kama_fast; int kama_slow;
   int rsi_per; int rsi_up; int rsi_low; int bb_per; double bb_dev; int filter_ema;
   int session_start; int session_end;
   double risk_percent; double atr_mult; int atr_per; int magic_number;
   ENUM_BIAS_MODE bias;
};

class CEngine
{
private:
   CTrade         m_trade;
   CPositionInfo  m_position;
   CRiskManager   m_risk;
   CRegimeFilter  m_regime;
   ISignal        *m_signals[];
   string         m_symbol;
   ENUM_TIMEFRAMES m_period;
   HydraSettings  m_settings;

   // Limpeza de Objetos Gráficos
   void ClearVisuals()
   {
      ObjectDelete(0, "Talos_TP_Line");
      ObjectDelete(0, "Talos_Status");
   }

   void DrawTPLine(double tp)
   {
      string name = "Talos_TP_Line";
      ObjectCreate(0, name, OBJ_HLINE, 0, 0, tp);
      ObjectSetInteger(0, name, OBJPROP_COLOR, clrGreen);
      ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_DOT);
      ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
      ObjectSetString(0, name, OBJPROP_TEXT, "TALOS TARGET");
   }

public:
   CEngine() : m_symbol(_Symbol), m_period(_Period) {}
   
   // CORREÇÃO DE MEMORY LEAK: Destrutor robusto
   ~CEngine() 
   { 
      for(int i=0; i<ArraySize(m_signals); i++) 
      {
         if(CheckPointer(m_signals[i]) == POINTER_DYNAMIC)
         {
            delete m_signals[i];
         }
      }
      ArrayFree(m_signals);
      ClearVisuals();
   }

   bool Init(const HydraSettings &settings)
   {
      m_settings = settings;
      m_trade.SetExpertMagicNumber(m_settings.magic_number);
      m_trade.SetTypeFillingBySymbol(m_symbol);
      if(!m_risk.Init(m_symbol, m_settings.risk_percent, m_settings.atr_mult, m_settings.atr_per)) return false;
      if(m_settings.use_adaptive) m_regime.Init(m_symbol, m_period, 25.0);

      ArrayResize(m_signals, 3);
      m_signals[0] = new CSignalKAMA(m_settings.kama_per, 2, 30);
      m_signals[1] = new CSignalMeanRev(m_settings.rsi_per, 70, 30, m_settings.bb_per, 2.0, 200);
      m_signals[2] = new CSignalBreakout(0, 8);

      for(int i=0; i<3; i++) m_signals[i].Init(m_symbol, m_period);
      return true;
   }

   void OnTick()
   {
      if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)) return;
      
      // Lógica de Trailing Stop / Monitoramento
      if(m_position.Select(m_symbol)) 
      {
         UpdateTrailingStop();
         DrawTPLine(m_position.TakeProfit());
         return;
      }
      else {
         ClearVisuals();
      }

      ENUM_MARKET_REGIME current_regime = m_settings.use_adaptive ? m_regime.GetRegime() : REGIME_UNKNOWN;

      for(int i=0; i<ArraySize(m_signals); i++)
      {
         if(m_settings.use_adaptive)
         {
            if(i == 0 && current_regime != REGIME_TRENDING) continue;
            if(i == 1 && current_regime != REGIME_RANGING) continue;
            if(i == 2) continue;
         }
         else
         {
            if(i == 0 && !m_settings.use_kama) continue;
            if(i == 1 && !m_settings.use_mean_rev) continue;
            if(i == 2 && !m_settings.use_breakout) continue;
         }

         ENUM_SIGNAL_TYPE sig = m_signals[i].CheckSignal();
         if(m_settings.bias == BIAS_LONG && sig == SIGNAL_SELL) sig = SIGNAL_NONE;
         if(m_settings.bias == BIAS_SHORT && sig == SIGNAL_BUY) sig = SIGNAL_NONE;

         if(sig != SIGNAL_NONE)
         {
            ExecuteTrade(sig, m_signals[i].GetName() + " [Adaptive]");
            return;
         }
      }
   }

   // NOVO: Trailing Stop Inteligente
   void UpdateTrailingStop()
   {
      double price = (m_position.PositionType() == POSITION_TYPE_BUY) ? SymbolInfoDouble(m_symbol, SYMBOL_BID) : SymbolInfoDouble(m_symbol, SYMBOL_ASK);
      double entry = m_position.PriceOpen();
      double stop = m_position.StopLoss();
      double tick_size = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_TICK_SIZE);

      // Se o lucro for maior que o risco inicial (1:1), move o Stop para o Breakeven + um pouco
      if(m_position.PositionType() == POSITION_TYPE_BUY && price > entry + (entry - stop))
      {
         double new_stop = entry + (10 * tick_size); 
         if(new_stop > stop) m_trade.PositionModify(m_position.Ticket(), NormalizeDouble(new_stop, (int)SymbolInfoInteger(m_symbol, SYMBOL_DIGITS)), m_position.TakeProfit());
      }
   }

   void ExecuteTrade(ENUM_SIGNAL_TYPE type, string comment)
   {
      double sl_dist = m_risk.GetStopLossDistance();
      if(sl_dist == 0) return;
      double lots = m_risk.CalculateLotSize(sl_dist);
      double price = (type == SIGNAL_BUY) ? SymbolInfoDouble(m_symbol, SYMBOL_ASK) : SymbolInfoDouble(m_symbol, SYMBOL_BID);
      double sl = (type == SIGNAL_BUY) ? price - sl_dist : price + sl_dist;
      double tp = (type == SIGNAL_BUY) ? price + (sl_dist * 2.5) : price - (sl_dist * 2.5);

      int digits = (int)SymbolInfoInteger(m_symbol, SYMBOL_DIGITS);
      m_trade.PositionOpen(m_symbol, (type == SIGNAL_BUY ? ORDER_TYPE_BUY : ORDER_TYPE_SELL), lots, NormalizeDouble(price, digits), NormalizeDouble(sl, digits), NormalizeDouble(tp, digits), comment);
   }
};