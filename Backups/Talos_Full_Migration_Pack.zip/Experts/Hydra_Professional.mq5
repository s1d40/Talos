//+------------------------------------------------------------------+
//|                                       Hydra_Professional.mq5     |
//|                                  Copyright 2026, Hydra Project.  |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Hydra Project."
#property version   "4.00"
#property strict

#include <Hydra\Core\CEngine.mqh>

//--- INPUTS GERAIS ---
input string   Inp_Group_Main = "=== Configurações Gerais ===";
input int      InpMagicNum    = 999001;      
input bool     InpAdaptive    = true;        // MODO ADAPTATIVO (Auto-Switch)
input ENUM_BIAS_MODE InpMacroBias = BIAS_NONE; // Viés Macro (Filtro Global)

//--- INPUTS DE RISCO ---
input string   Inp_Group_Risk = "=== Gestão de Risco ===";
input double   InpRiskPercent = 1.0;         
input int      InpATRPeriod   = 14;          
input double   InpATRMult     = 2.5;         

//--- INPUTS MANUAIS (Ignorados se Adaptive=true) ---
input string   Inp_Group_Man  = "=== Seleção Manual (Se Adaptive=false) ===";
input bool     InpUseKAMA     = true;        
input bool     InpUseMeanRev  = true;        
input bool     InpUseBreakout = false;       

//--- INPUTS TÉCNICOS ---
input string   Inp_Group_Tec  = "=== Parâmetros Técnicos ===";
input int      InpKAMA_Per    = 10;
input int      InpRSI_Per     = 14;
input int      InpBB_Per      = 20;

CEngine engine;

int OnInit()
{
   HydraSettings settings;
   settings.magic_number = InpMagicNum;
   settings.use_adaptive = InpAdaptive; // Passa a escolha do usuário
   settings.bias         = InpMacroBias;
   
   settings.risk_percent = InpRiskPercent;
   settings.atr_mult     = InpATRMult;
   settings.atr_per      = InpATRPeriod;
   
   settings.use_kama     = InpUseKAMA;
   settings.use_mean_rev = InpUseMeanRev;
   settings.use_breakout = InpUseBreakout;
   
   settings.kama_per     = InpKAMA_Per;
   settings.kama_fast    = 2;
   settings.kama_slow    = 30;
   
   settings.rsi_per      = InpRSI_Per;
   settings.rsi_up       = 70;
   settings.rsi_low      = 30;
   settings.bb_per       = InpBB_Per;
   settings.bb_dev       = 2.0;
   settings.filter_ema   = 200;
   
   settings.session_start= 0;
   settings.session_end  = 8;
   
   if(!engine.Init(settings)) return INIT_FAILED;
   return INIT_SUCCEEDED;
}

void OnTick() { engine.OnTick(); }