# **Talos Quantamental Expert Advisor (EA)**
> **A Fusão entre Inteligência Macro e Execução Algorítmica de Alta Precisão.**

![MetaTrader 5](https://img.shields.io/badge/Platform-MetaTrader%205-blue.svg)
![License](https://img.shields.io/badge/License-Proprietary-red.svg)
![Architecture](https://img.shields.io/badge/Architecture-Object--Oriented-green.svg)

## **1. Visão Geral**
O **Talos Quantamental** (anteriormente Hydra) é um Expert Advisor de elite desenvolvido para o MetaTrader 5. Diferente de robôs convencionais baseados puramente em indicadores técnicos, o Talos utiliza uma abordagem **Quantamental** — integrando diretrizes macroeconômicas globais (Deep Research) com motores algorítmicos adaptativos.

O sistema foi projetado para operar sob o paradigma da **Divergência Monetária**, permitindo que o operador humano defina o viés fundamental (Bias Overlay) enquanto o algoritmo gerencia o *timing* técnico e a gestão de risco matemática.

## **2. Arquitetura Técnica**
O projeto segue rigorosamente os princípios de **Programação Orientada a Objetos (POO)** em C++, garantindo modularidade e baixa latência:

*   **Core Engine (`CEngine`):** Orquestrador central que gerencia o fluxo de dados, estado da conta e roteamento de ordens.
*   **Adaptive Regime Switch:** Filtro inteligente baseado em ADX (Average Directional Index) que alterna em tempo real entre dois motores de execução:
    *   **Motor Trending (KAMA):** Captura movimentos direcionais explosivos usando médias móveis adaptativas.
    *   **Motor Ranging (Mean Reversion):** Lucra em mercados laterais através de desvios estatísticos (Bollinger Bands + RSI).
*   **Bias Overlay Module:** Filtro proprietário que permite travar o robô em modos *Long-Only*, *Short-Only* ou *Bi-Directional*, alinhando a execução técnica com o cenário geopolítico.

## **3. Gestão de Risco Institucional**
A preservação de capital é o núcleo do Talos. O robô utiliza o **`CRiskManager`** para:
*   **Dynamic Lot Sizing:** Cálculo automático do volume da ordem baseado em uma porcentagem fixa do patrimônio líquido.
*   **ATR-Based Stops:** Stop Loss e Take Profit calculados dinamicamente com base na volatilidade real do ativo (Average True Range), evitando *stop-outs* por ruído de mercado.
*   **Anti-Repainting Logic:** Execução baseada estritamente em velas fechadas, garantindo que o que você vê no backtest é exatamente o que acontece na conta real.

## **4. Estratégias Inclusas**
1.  **Kaufman Trend Follower:** Filtro de ruído via inclinação de média adaptativa.
2.  **Bollinger/RSI Divergence:** Identificação de exaustão de preço com filtros de tendência macro (EMA 200).
3.  **Session Breakout:** Captura de expansão de volatilidade em janelas horárias específicas (ex: Londres/NY).

## **5. Instalação e Configuração**
### **Estrutura de Pastas:**
```text
MQL5/
  |-- Experts/
  |     |-- Hydra_Professional.mq5 (Main)
  |-- Include/
  |     |-- Hydra/
  |           |-- Core/
  |           |-- Signals/
  |           |-- Risk/
  |           |-- Utils/
```
### **Requisitos:**
*   Plataforma: MetaTrader 5
*   Timeframes Recomendados: M15 (Ouro/Índices), H1 (Moedas/Petróleo).
*   Ambiente: Windows 10/11 ou Linux (via Wine/Bottles).

## **6. Roadmap de Desenvolvimento**
- [x] Implementação de POO Modular.
- [x] Filtro de Viés Macro (Bias Overlay).
- [x] Modo Adaptativo de Regime (Auto-Switch).
- [ ] Interface Gráfica (Dashboard On-Chart).
- [ ] Notificações Push/Telegram.
- [ ] Lançamento no MQL5 Market.

## **7. Aviso Legal (Disclaimer)**
O trading de ativos financeiros envolve risco significativo de perda de capital. O Talos Quantamental é uma ferramenta de automação e não garante lucros futuros. O desempenho passado não é garantia de resultados futuros. Use sempre em conta demonstração antes de migrar para capital real.

---
**Desenvolvido por Sidnei Felipe & Gemini AI Engine.**
*© 2026 Project Talos. Todos os direitos reservados.*
